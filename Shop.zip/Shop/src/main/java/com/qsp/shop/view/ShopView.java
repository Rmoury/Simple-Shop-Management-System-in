package com.qsp.shop.view;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

import com.qsp.shop.controller.ShopController;
import com.qsp.shop.model.Product;

public class ShopView {

	static Scanner s = new Scanner(System.in);
	static Product product = new Product();
	static ShopController shopController = new ShopController();

	
	public static void main(String[] args) {
		
	
		do {
			System.out.println("Select operation to perform : ");
			System.out.println("1.Add product\n2.Remove product\n3.Update product details\n4.fetch product\n0.exit");
		    System.out.println("Enter digit respective to desired option : ");
		    int userinput=s.nextInt();
		    s.nextLine();
		    switch(userinput) {
		    case 0:
		    	s.close();
		    	System.err.println(".....EXITED.....");
		    	System.exit(0);
		     break;	
		    case 1:
		    	System.out.println("do you want to add one(press 1) or muliple (any other number except 1) ");
				int productsCount = s.nextInt();
				s.nextLine();
				if (productsCount == 1) {
		    	System.out.println("Enter porduct id : ");
		    	int i_p_id=s.nextInt();
		    	s.nextLine();
		    	System.out.print("Enter product name : ");
		    	String i_p_name=s.nextLine();
		    	System.out.println("Enter price : ");
		    	int i_p_quantity=s.nextInt();
		    	s.nextLine();
		    	boolean i_p_availability=false;
		    	if(i_p_quantity>0) {
		    		i_p_availability=true;
		    	}
		    	 {
		    		if((shopController.addProduct(i_p_id,i_p_name,i_p_price,i_p_quantity,i_p_availability)) !=0) {
			    		System.out.println("Product added");
			    	}else {
			    		System.out.println("Product not added");

			    	}
		    	 }
				}
		    	
		    else {boolean toContinue = true;
		    	ArrayList<Product> products = new ArrayList<Product>();
		    		do {
		    			Product product = new Product();
		    			System.out.println("enter id :");
		    			product.setP_id(s.nextInt());
		    			s.nextLine();
		    			System.out.println("enter name :");
		    			product.setP_name(s.nextLine());
		    			System.out.println("enter price :");
		    			product.setP_price(s.nextInt());
		    			s.nextLine();
		    			System.out.println("enter quantity :");
		    			int quantity=s.nextInt();
		    			product.setP_quantity(quantity);
		    			s.nextLine();
		    			boolean i_p_availability=false;
		    			if(quantity>0){
		    				i_p_availability=true;
		    			}
		    			product.setP_availability(i_p_availability);
		    			products.add(product);
		    		}while (true);
		    	
				System.out.println("do you want to add further yes(1) or no(0) : ");
				int toAdd = s.nextInt();
				s.nextLine();
				if (toAdd == 0) {
				 toContinue = false;
				
			} while (false);
			shopController.addMultipleProducts(products);
		}
			     break;	
			     case 2:
			//Handle product removal
			System.out.println("Enter product id to remove :");
			int productIdToRemove=s.nextInt();
			s.nextLine();
			if(shopController.removeProduct(productIdToRemove)!=0) {
				System.out.println("ha delete hogaya");
			}else {System.out.println("Product with given id does not exists,No remove operation performed ");
			}
			System.out.println();
			    break;
		case 3:
			//handle product details update
			System.out.println("Enter product id to update :");
			int productIdToUpdate=s.nextInt();
			s.nextLine();
			ResultSet product=shopController.fetchProduct(productIdToUpdate);
			if (product.next()) {
				 System.out.println("What you want to update ?");
				 System.out.println("1.Name\n2.Price\n3.Quantity");
				 System.out.println("Enter number respective to desired option :");
			} else { 
				System.out.println("Product with given id does not exist,Upadte operation performed :");
				byte updateOption=s.nextByte();
				s.nextLine();
				switch (updateOption) {
				case 1:
					System.out.println("Enter name to update : ");
					String nameToUpdate=s.nextLine();
					if(shopController.UpdateProductName(productIdToUpdate, nameToUpdate)) {
						System.out.println("Record not update");
					}else {
						System.out.println("Record not updated.");
					}
					break;
                 case 2:
					
					break;
                 case 3:
 					
 					break;
                 

				default:
					System.out.println("INVALID SELECTION");
					break;
				}

			}else {System.out.println("Product with given id is not available ");
			   break;
		case 4: 
			//handle product fetching
                System.out.println("ghjj");
                int productIdToFind=s.nextInt();
                s.nextLine();
                ResultSet fetchProduct = shopController.fetchProduct(productIdToFind);
                boolean next=fetchProduct.next();
                if(next) {
                	System.out.println("PRODUCT DETAILS");
                	System.out.println("id:"+fetchProduct.getInt(1));
                	System.out.println("Name :"+fetchProduct.getString(2));
                	System.out.println("Price :"+fetchProduct.getInt(3));
                	System.out.println("Quantity :"+ fetchProduct.getInt(4));
                	if(fetchProduct.getBoolean(5)) {
                		System.out.println("Availability : Available");
                	}else {
                		System.out.println("Availability : Not Available");
                	}
                	System.out.println();
                }else {
                	System.out.println("Product with id: "+productIdToFind +" does not exist.");
                	System.out.println();
                }
                
                
                
			break;
			
		case 5:
			
			break;
		default:
			System.out.println("- - - - INVALID SELECTION - - - -");
			break;
		}
	} while (true);
	

		

}